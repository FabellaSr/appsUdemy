import { useForm } from 'react-hook-form';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useMembers } from '@/pages/members/hooks/useMembers';
import { useCreateMemberSalaries } from '../hooks/useCreateMemberSalaries';
import { useUpdateMemberSalaries } from '../hooks/useUpdateMemberSalaries';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  year: number;
  month: number;
  // Si se pasa id + salary se intenta editar
  userId?: string;
  currentSalaryAmount?: number;
}

// Una clave por miembro: salaries.{userId}
type FormValues = {
  salaries: Record<string, string>; // string para permitir campo vacío
};

export function MemberSalaryDialog({
  open,
  onOpenChange,
  year,
  month,
  userId,
  currentSalaryAmount
}: Props) {

  const isEditing = userId !== undefined;

  const { data: members, isLoading } = useMembers();
  const { mutateAsync, isPending } = useCreateMemberSalaries(year, month);
  const useUpdateSalaryMutation = useUpdateMemberSalaries(year, month);

  const { register, handleSubmit, reset } = useForm<FormValues>({
    defaultValues: { salaries: {} },
  });

  const onSubmit = async (values: FormValues) => {
    if (isEditing) {
      
      await useUpdateSalaryMutation.mutateAsync({ userId: userId!, salary: currentSalaryAmount! })
    }
    else {
      // Solo enviar miembros con salario ingresado (> 0)
      const entries = Object.entries(values.salaries)
        .filter(([, val]) => val !== '' && Number(val) > 0)
        .map(([userId, val]) => ({ userId, salary: Number(val) }));

      if (!entries.length) return;
      await mutateAsync(entries);
    }

    reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle>Salarios de {month}/{year}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 py-4">
          {isLoading && (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-10 animate-pulse rounded-md bg-muted" />
              ))}
            </div>
          )}

          {!isLoading && members.length === 0 && (
            <p className="text-sm text-muted-foreground">
              No hay miembros cargados todavía.
            </p>
          )}

          {!isLoading && members.length > 0 && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Ingresá el salario de cada miembro. Podés dejar en blanco a quien no participe este mes.
              </p>

              {members.map((member) => (
                <div key={member.id} className="space-y-1">
                  <Label>{member.name}</Label>
                  <Input
                    type="number"
                    placeholder="0"
                    {...register(`salaries.${member.id}`, { min: 0 })}
                  />
                </div>
              ))}
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isPending || isLoading}>
              {isPending ? 'Guardando...' : 'Guardar salarios'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
